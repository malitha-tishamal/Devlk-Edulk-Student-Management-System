<?php
session_start();
require_once '../includes/db-conn.php';

if (!isset($_SESSION['sadmin_id'])) {
    header("Location: ../index.php");
    exit();
}

$user_id = $_SESSION['sadmin_id'];
$sql = "SELECT name, email, nic, mobile, profile_picture FROM sadmins WHERE id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();
$user = $result->fetch_assoc();
$stmt->close();

$recordings = $conn->query("SELECT r.*, s.name AS subject_name FROM recordings r JOIN subjects s ON r.subject_id = s.id ORDER BY release_time DESC");
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>Video Resources</title>

  <!-- Bootstrap CSS -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">

  <!-- FontAwesome CDN -->
  <link
    rel="stylesheet"
    href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css"
    crossorigin="anonymous"
    referrerpolicy="no-referrer"
  />

  <style>
    .resource-card.disabled {
      opacity: 0.5;
      pointer-events: none;
    }
    .resource-icon {
      font-size: 1.75rem;
      color: #0d6efd;
      width: 40px;
      text-align: center;
    }
    .subject-header {
      margin-top: 2rem;
      margin-bottom: 1rem;
      font-weight: 700;
      color: #0d6efd;
      border-bottom: 2px solid #0d6efd;
      padding-bottom: 4px;
    }
  </style>
</head>
<body>
  <?php include_once("../includes/header.php"); ?>
  <?php include_once("../includes/sadmin-sidebar.php"); ?>

  <main id="main" class="main container my-4">
    <div class="pagetitle mb-4">
      <h1>Video Resources</h1>
      <nav>
        <ol class="breadcrumb">
          <li class="breadcrumb-item"><a href="index.php">Home</a></li>
          <li class="breadcrumb-item active">Resources</li>
        </ol>
      </nav>
    </div>

    <?php
    $currentSubject = null;
    while ($row = $recordings->fetch_assoc()):
      if ($currentSubject !== $row['subject_name']):
        if ($currentSubject !== null) echo "</div>"; // Close previous subject's row
        echo "<h3 class='subject-header'>" . htmlspecialchars($row['subject_name']) . "</h3><div class='row'>";
        $currentSubject = $row['subject_name'];
      endif;

      // Fetch resources for this recording
      $resources = $conn->prepare("SELECT * FROM recording_resources WHERE recording_id = ?");
      $resources->bind_param("i", $row['id']);
      $resources->execute();
      $resResult = $resources->get_result();
    ?>

    <div class="col-md-4 mb-4">
      <div class="card h-100 shadow-sm">
        <div class="card-body d-flex flex-column">
          <h5 class="card-title"><?= htmlspecialchars($row['title']) ?></h5>
          <div class="mb-3">
          <div class="flex-grow-1 overflow-auto" style="max-height: 280px;">
            <?php if ($resResult->num_rows === 0): ?>
              <p class="text-muted">No resources added.</p>
            <?php else: while ($res = $resResult->fetch_assoc()): ?>
              <div id="resource-card-<?= $res['id'] ?>" class="d-flex align-items-center justify-content-between p-3 mb-3 border rounded resource-card <?= ($res['status'] ?? '') === 'disabled' ? 'disabled' : '' ?>">
                <div class="d-flex align-items-center gap-3 flex-grow-1">
                  <div class="resource-icon">
                    <?php if (($res['type'] ?? '') === 'file'): ?>
                      <i class="fa-solid fa-file-arrow-down"></i>
                    <?php elseif (($res['type'] ?? '') === 'link'): ?>
                      <i class="fa-solid fa-link"></i>
                    <?php else: ?>
                      <i class="fa-solid fa-question"></i>
                    <?php endif; ?>
                  </div>
                  <div>
                    <div class="fw-semibold"><?= htmlspecialchars($res['title'] ?? 'No Title') ?></div>
                    <small class="text-muted">Uploaded at: <?= htmlspecialchars($res['uploaded_at'] ?? 'Unknown') ?></small>
                  </div>
                </div>

                <div class="d-flex align-items-center gap-2">
                  <?php if (($res['type'] ?? '') === 'file' && !empty($res['file_path'])): ?>
                    <a href="../<?= htmlspecialchars($res['file_path']) ?>" target="_blank" download class="btn btn-outline-primary btn-sm">
                      <i class="fa-solid fa-download me-1"></i> Download
                    </a>
                  <?php elseif (($res['type'] ?? '') === 'link' && !empty($res['link_url'])): ?>
                    <a href="<?= htmlspecialchars($res['link_url']) ?>" target="_blank" rel="noopener noreferrer" class="btn btn-outline-primary btn-sm">
                      <i class="fa-solid fa-link me-1"></i> Visit Link
                    </a>
                  <?php else: ?>
                    <span class="text-muted fst-italic">Unavailable</span>
                  <?php endif; ?>

                  <button onclick="toggleResourceStatus(<?= $res['id'] ?>)" title="Toggle Active/Disable" class="btn btn-sm btn-warning">
                    <?= ($res['status'] ?? '') === 'disabled' ? 'Enable' : 'Disable' ?>
                  </button>

                  <button onclick="deleteResource(<?= $res['id'] ?>)" title="Delete Resource" class="btn btn-sm btn-danger">
                    <i class="fa-solid fa-trash"></i>
                  </button>
                </div>
              </div>
            <?php endwhile; endif; ?>
          </div>
        </div>
      </div>
    </div>

    <?php
    endwhile;
    if ($currentSubject !== null) echo "</div>"; // Close last subject row
    ?>
  </main>

  <?php include_once("../includes/footer2.php"); ?>
  <?php include_once("../includes/js-links-inc.php"); ?>

  <!-- Bootstrap JS (for any bootstrap components that need JS) -->
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>

  <script>
    function toggleResourceStatus(resourceId) {
      fetch('toggle_resource_status.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ id: resourceId })
      })
      .then(res => res.json())
      .then(data => {
        if (data.error) {
          alert('Error: ' + data.error);
          return;
        }
        const card = document.getElementById('resource-card-' + resourceId);
        if (!card) return;

        const toggleBtn = card.querySelector('button[title="Toggle Active/Disable"]');
        const links = card.querySelectorAll('.resource-actions a, a.btn');

        if (data.status === 'disabled') {
          card.classList.add('disabled');
          toggleBtn.textContent = 'Enable';
          // Disable links/buttons except toggle and delete
          card.querySelectorAll('a.btn').forEach(el => el.style.pointerEvents = 'none');
        } else {
          card.classList.remove('disabled');
          toggleBtn.textContent = 'Disable';
          card.querySelectorAll('a.btn').forEach(el => el.style.pointerEvents = '');
        }
      })
      .catch(err => {
        alert('Error toggling status: ' + err);
      });
    }

    function deleteResource(resourceId) {
      if (!confirm('Are you sure you want to delete this resource?')) return;
      fetch('delete-video-resource.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ id: resourceId })
      })
      .then(res => res.json())
      .then(data => {
        if (data.error) {
          alert('Error deleting resource: ' + data.error);
          return;
        }
        const card = document.getElementById('resource-card-' + resourceId);
        if (card) card.remove();
      })
      .catch(err => {
        alert('Error deleting resource: ' + err);
      });
    }
  </script>
</body>
</html>
